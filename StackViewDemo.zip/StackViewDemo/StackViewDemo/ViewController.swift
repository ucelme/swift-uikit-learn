//
//  ViewController.swift
//  StackViewDemo
//
//  Created by Simon Ng on 11/8/2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

